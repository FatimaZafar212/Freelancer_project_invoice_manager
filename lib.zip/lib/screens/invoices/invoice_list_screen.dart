import 'package:flutter/material.dart';
import '../../services/firestore_service.dart';
import 'create_invoice_screen.dart';

class InvoiceListScreen extends StatelessWidget {
  const InvoiceListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Invoices')),

      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const CreateInvoiceScreen()),
          );
        },
        child: const Icon(Icons.add),
      ),

      body: StreamBuilder(
        stream: FirestoreService().getInvoices(),
        builder: (context, snapshot) {

          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final invoices = snapshot.data!.docs;

          if (invoices.isEmpty) {
            return const Center(child: Text("No invoices yet"));
          }

          return ListView.builder(
            itemCount: invoices.length,
            itemBuilder: (context, index) {
              final invoice = invoices[index];

              return Card(
                margin: const EdgeInsets.all(10),
                child: ListTile(
                  title: Text("Invoice ${index + 1}"),

                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Client: ${invoice['clientId']}"),
                      Text("Status: ${invoice['status']}"),
                    ],
                  ),

                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [

                      // 💰 TOTAL
                      Text("Rs ${invoice['total']}"),

                      const SizedBox(height: 5),

                      // ✅ MARK AS PAID BUTTON
                      GestureDetector(
                        onTap: () async {
                          await invoice.reference.update({
                            'status': 'Paid'
                          });

                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text("Marked as Paid")),
                          );
                        },
                        child: const Text(
                          "Mark Paid",
                          style: TextStyle(
                            color: Colors.green,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),

                  // ❌ DELETE BUTTON
                  onLongPress: () async {
                    await invoice.reference.delete();

                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text("Invoice Deleted")),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}